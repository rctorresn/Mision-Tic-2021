package com.usa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
